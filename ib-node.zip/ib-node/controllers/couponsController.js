let app = require('express');
let router = app.Router();
let coupons = require('../models').coupons;
let sub_domains = require('../models').sub_domains;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;
var randomize = require('randomatic');

router.post('/generate',(req,res)=>{
      if(req.auth.access.addAccess){
            let user_data = req.body;
            let newinsData = [];
            for(let q=0;q<user_data.no_of_coupans;q++){
                  let code = user_data.type=='discount' ? user_data.code : randomize('Aa0', 6);
                  newinsData.push({type:user_data.type,code:code,discount:user_data.discount,expDate:user_data.expDate,status:'generated',userId:req.auth.userId,maxAmount:user_data.maxAmount});
            }
            coupons.bulkCreate(newinsData).then(data=>{
                  res.send({'status':true,"message":"Coupans Generated."})
            }).catch(err=>{
                  res.send({status:false,message:'failed.'});
            });
      }else{
            res.send({status:false,message:'un Authorized.'});
      }
});

router.get('/validate/:id',(req,res)=>{
      coupons.findOne({attributes:['discount','status','expDate','type','maxAmount'],where:[{code:req.params.id}]}).then(data=>{
            let status = data.status=='generated' ? true : false; 
            res.send({status:status,data:data});
      }).catch(err=>{
            res.send({status:false,message:'fail'});
      })
});

router.get('/',(req,res)=>{
      if(req.auth.access.gridAccess){
            coupons.findAll({
                  attributes: ['type','code', 'discount','expDate','status','maxAmount',[sequelize.fn('count', sequelize.col('code')),'codescount']], 
                  group: ['code','type', 'discount','expDate','status']
                }).then(result=>{
                  res.send({status:true,data:result,access:req.auth.access});
            }).catch(err=>{
                  res.send({status:false,message:'fail',access:req.auth.access});
            })
      }else{
            res.send({status:false,message:'un Authorized.',access:req.auth.access});
      }
});


module.exports = router;

/* ***********************
 * client id : AeF5eVbR7vJETzy3XVMz1PSozIUUP0pVvqfc9qADFO3xkwhJi1rkkht-8yKx6TNb9ihNeg-eLdAgJYNL
 secreat : EAyj5ubFxYcLbfLdz0sVyfywNYbrR_a-MSf119C0u_SdFGhf2pB_Cp2nXReoDW7vfK9KmEgWKkq9goVn
 * ********************** */

