/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_users = sequelize.define('interview_users', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    interviewId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview',
        key: 'id'
      }
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('Available','Verified','Submitted','Completed','Reviewed',"expertreview"),
      allowNull: false
    },
    link: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    pin: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    paymentstatus:{
      type: DataTypes.TEXT
    },
    interviewTypeMapChildId:{
      type: DataTypes.INTEGER(11),
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_users'
  });

  interview_users.associate = function(models) {
    interview_users.hasMany(models.interview_user_questions, {foreignKey: 'interviewUserId', targetKey: 'id'});
    interview_users.belongsTo(models.interview, {foreignKey: 'interviewId', targetKey: 'id'});
    interview_users.belongsTo(models.interview_type_map_child, {foreignKey: 'interviewTypeMapChildId', targetKey: 'id'});
    interview_users.belongsTo(models.users, {foreignKey: 'email', targetKey: 'email'});
  };

  return interview_users;
};
