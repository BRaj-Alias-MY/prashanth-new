'use strict';
module.exports = (sequelize, DataTypes) => {
  const AsyncMocks = sequelize.define (
    'AsyncMocks',
    {
      InterviewId: DataTypes.INTEGER,
      q_title: DataTypes.STRING,
      ano: DataTypes.INTEGER,
      uid: DataTypes.STRING,
      answer: DataTypes.STRING,
      videoURL: DataTypes.STRING,
      userId: DataTypes.INTEGER,
      email: DataTypes.STRING,
      status: DataTypes.INTEGER,
      max_count: DataTypes.INTEGER,
      time_taken: DataTypes.STRING,
    },
    {}
  );
  AsyncMocks.associate = function (models) {
    // associations can be defined here
  };
  return AsyncMocks;
};
