import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  constructor() { }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    // const worksheet1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    // const worksheet2: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    let sheetsconst = {};
    let shtnames = [];
    for(let ii=0;ii<json.length;ii++){
      sheetsconst[json[ii].sheetname] = XLSX.utils.json_to_sheet(json[ii].sheetvalue);
      shtnames.push(json[ii].sheetname);
    }
    const workbook: XLSX.WorkBook = { Sheets: sheetsconst, SheetNames: shtnames };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);

    // const wb = {
    //   Sheets: {
    //     Sheet1: {
    //       '!dataValidation': [
    //         {sqref: 'A1:A99', values: ['foo', 'bar', 'baz']},
    //         {sqref: 'B1:B99', values: ['Africa', 'Asia', 'Europe', 'America', 'Australia']},
    //       ]
    //     }
    //   },
    //   SheetNames: ['Sheet1']
    // }
    
    // const buff = XLSX.write(wb, {type: 'buffer'});
    // this.saveAsExcelFile(buff, excelFileName);
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
     const data: Blob = new Blob([buffer], {type: EXCEL_TYPE});
     FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);
  }

  public importExcel(file:any[]){
    var data = new Uint8Array(file);
    var wb = XLSX.read(data,{type:'array'});
    return XLSX.write(wb,{sheet:"Data", type:'binary',bookType:'csv'});
  }
}
