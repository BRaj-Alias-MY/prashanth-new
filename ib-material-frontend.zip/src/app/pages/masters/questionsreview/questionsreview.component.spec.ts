import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionsreviewComponent } from './questionsreview.component';

describe('QuestionsreviewComponent', () => {
  let component: QuestionsreviewComponent;
  let fixture: ComponentFixture<QuestionsreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionsreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionsreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
