import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormArray, FormControl } from "@angular/forms";
import {
  FileUploader,
  FileSelectDirective
} from "ng2-file-upload/ng2-file-upload";
import { FormBuilder } from "@angular/forms";
import { Router } from "@angular/router";
import { Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { UsersService } from "../services/users.service";
import { ValidationService } from "../../../services/validation.service";
import { GridOptions } from "ag-grid-community";
import { ChildMessageRenderer } from "../../../childmessagerender.component";

const URL = "http://localhost:3000/api/userprofile/upload";

@Component({
  selector: "app-userprofile",
  templateUrl: "./userprofile.component.html",
  styleUrls: ["./userprofile.component.css"]
})
export class UserprofileComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private route: Router,
    private api: UsersService,
    private http: HttpClient
  ) {
    // this.gridOptions = <GridOptions>{
    // 	paginationNumberFormatter: function(params) {
    // 		return '[' + params.value.toLocaleString() + ']';
    // 	}
    // };
    // this.columnDefs = [
    // 	{ headerName: 'Name', field: 'name' },
    // 	{ headerName: 'Type', field: 'type' },
    // 	{ headerName: 'URL', field: 'url' },
    // 	{ headerName: 'Email', field: 'email' },
    // 	{ headerName: 'ID', field: 'id', hide: true },
    // 	{
    // 		headerName: 'Action',
    // 		cellRenderer: 'childMessageRenderer',
    // 		colId: 'params',
    // 		value: 'id'
    // 	}
    // ];
    this.frameworkComponents = {
      childMessageRenderer: ChildMessageRenderer
    };
    this.context = { componentParent: this };
  }
  edu;
  exp;
  up_val: any;
  index = "";
  rpt_btn_name = "";
  update;
  items;
  btn_update = "Update";
  btn_add = "Add";
  private gridOptions: GridOptions;
  private gridApi;
  private gridColumnApi;

  private columnDefs;
  private rowData;
  private context;
  private frameworkComponents;

  selectedFile: File;

  public uploader: FileUploader = new FileUploader({
    url: URL,
    itemAlias: "doc",
    headers: [{ name: "authorization", value: localStorage.getItem("token") }]
  });

  userprofileForm = this.fb.group({
    id: [],
    about: [""],
    address: [""],
    zipcode: [""],
    linkedin: [""],
    resume: [""]
  });

  educationRepeat = this.fb.group({
    education: [""],
    university: [""],
    courseFrom: [""],
    courseTo: [""],
    specilization: [""],
    grade: [""]
  });

  experianceRepeat = this.fb.group({
    organizationName: [""],
    desgination: [""],
    joinedDate: [""],
    relivedDate: [""]
  });

  access;
  IsForUpdate = false;
  newItem: any = {};
  updatedItem;
  btn_name: string;
  current_page: number;
  start_record: number;
  pages;
  total_records: number;
  grid_tab;
  mydata = [];
  sh_add: boolean;
  editprofile: boolean;
  togel_name: string;
  view_item: any;
  onEditClick(id) {
    console.log(id);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    params.api.sizeColumnsToFit();
  }

  methodFromParentEdit(cell, valls) {
    // Swal("Edit");
    console.log(valls.id);
    this.EditItem(valls.id);
  }

  methodFromParentView(cell, valls) {
    // Swal("View");
    console.log(valls);
    this.ViewItem(valls.id);
  }
  EditItem(item_id) {
    // console.log(item_id);
    this.sh_add = true;
    this.togel_name = "Close";
    this.btn_name = "Update";
    this.userprofileForm.patchValue(this.get_item_data_with_id(item_id));
    this.edu = this.get_item_data_with_id(item_id).organization_campuses;
    console.log(this.edu);
  }
  get_item_data_with_id(item_id) {
    for (let i = 0; i < this.grid_tab.length; i++) {
      if (this.grid_tab[i].id == item_id) {
        return this.grid_tab[i];
      }
    }
  }
  ngOnInit() {
    this.uploader.onAfterAddingFile = file => {
      file.withCredentials = false;
    };
    this.uploader.onCompleteItem = (
      item: any,
      response: any,
      status: any,
      headers: any
    ) => {
      console.log("ImageUpload:uploaded:", item, status, response);
      alert("File uploaded successfully");
      this.btn_name = "Save";
    };
    this.grid_tab = [];
    this.items = {
      about: "",
      address: "",
      pincode: "",
      linkedin: "",
      education: "",
      experiance: "",
      fileupload: ""
    };

    this.sh_add = false;
    this.editprofile = false;
    this.togel_name = "Add";
    this.edu = [];
    this.exp = [];
    this.btn_name = "Save";
    this.mydata = [];
    this.view_item = [];
    this.current_page = 1;
    this.pages = [];
    this.start_record = 1;
    this.update = false;
    this.access = [];
    this.rpt_btn_name = this.btn_add;
    this.up_val = "";
    this.grid();
  }

  addEducationdetails() {
    /*let iem = this.organizationRepeat.value;
	this.organization.push(iem); */
    if (this.rpt_btn_name == this.btn_add) {
      this.edu.push(this.educationRepeat.value);
      // console.log(this.educationRepeat.value);
    } else if (this.rpt_btn_name == this.btn_update) {
      this.edu[this.index] = this.educationRepeat.value;
      // console.log(this.educationRepeat.value);
    } else {
      Swal.fire("Error in Form. Please try again later.");
    }
    // console.log(this.edu);
    this.clear_fields();
    this.rpt_btn_name = this.btn_add;
    // this.saveedu();
  }
  saveedu() {
    console.log(this.educationRepeat.value);
    this.api.save_userprofile_edu(this.edu).subscribe(res => {
      if (res.status) {
        // this.grid();
        Swal.fire(
          "Success..",
          "Record insert/updated successfully.",
          "success"
        );
        this.educationRepeat.patchValue({
          education: "",
          university: "",
          courseFrom: "",
          courseTo: "",
          specilization: "",
          grade: ""
        });

        // this.clear_fields();
      } else {
        // this.loading.hide();
        Swal.fire("Oops...", "Something went wrong!", "error");
      }
    });
  }
  add_togel() {
    this.sh_add = this.sh_add ? false : true;
    this.togel_name = this.togel_name == "Add" ? "Close" : "Add";
    this.btn_name = "Save";
    // this.userprofileForm.patchValue({ id: '', about: '' });
    this.edu = [];
  }
  paginate_fun(ppg) {
    this.current_page = ppg;
    // this.grid();
  }
  addExperiancedetails() {
    /*let iem = this.organizationRepeat.value;
	this.organization.push(iem); */
    this.userprofileForm.value.edu = this.edu;
    if (this.rpt_btn_name == this.btn_add) {
      this.exp.push(this.experianceRepeat.value);
    } else if (this.rpt_btn_name == this.btn_update) {
      this.exp[this.index] = this.experianceRepeat.value;
    } else {
      Swal.fire("Error in Form. Please try again later.");
    }

    this.clear_fields();
    this.rpt_btn_name = this.btn_add;
  }
  add_togel1() {
    this.sh_add = this.sh_add ? false : true;
    this.togel_name = this.togel_name == "Add" ? "Close" : "Add";
    this.btn_name = "Save";
    this.userprofileForm.patchValue({ id: "", about: "" });
    this.exp = [];
  }
  saveexp() {
    console.log(this.experianceRepeat.value);
    this.api.save_userprofile_exp(this.exp).subscribe(res => {
      if (res.status) {
        // this.grid();
        Swal.fire(
          "Success..",
          "Record insert/updated successfully.",
          "success"
        );
        this.experianceRepeat.patchValue({
          organizationName: "",
          desgination: "",
          joinedDate: "",
          relivedDate: ""
        });

        // this.clear_fields();
      } else {
        // this.loading.hide();
        Swal.fire("Oops...", "Something went wrong!", "error");
      }
    });
  }

  grid() {
    // console.log(this.current_page);
    this.api.getuserList().subscribe(data => {
      this.mydata = data.data;
      console.log(this.mydata);
      this.view_item = [];
      //this.profile = true;
    });
  }

  about() {
    console.log(this.userprofileForm.value);
    this.api.save_userprofile(this.userprofileForm.value).subscribe(res => {
      if (res.status) {
        Swal.fire(
          "Success..",
          "Record insert/updated successfully.",
          "success"
        );

        // this.clear_fields();
      } else {
        // this.loading.hide();
        Swal.fire("Oops...", "Something went wrong!", "error");
      }
    });
  }

  ViewItem(item_id) {
    this.view_item.push(this.get_item_data_with_id(item_id));
    console.log(this.view_item);
    this.sh_add = false;
    this.togel_name = "Add";
  }

  back_view() {
    this.view_item = [];
  }
  // Edit Item
  Editorgrepeat(profile, index) {
    this.index = index;
    //this.userprofileForm.patchValue(profile);
    //this.organizationRepeat.patchValue(purchase);
    this.editprofile = true;
    this.rpt_btn_name = this.btn_update;
  }
  // Edit Item
  EditCoverItem(profile, index) {
    this.index = index;
    this.educationRepeat.patchValue(profile);
    this.rpt_btn_name = this.btn_update;
  }
  // Edit Item
  EditCoverItem1(profile, index) {
    this.index = index;
    this.experianceRepeat.patchValue(profile);
    this.rpt_btn_name = this.btn_update;
  }

  clear_fields1() {
    this.educationRepeat.patchValue({
      educationname: "",
      university: "",
      coursefrom: "",
      courseto: "",
      specialization: "",
      grade: ""
    });
    this.rpt_btn_name = this.btn_add;
  }
  clear_fields2() {
    this.experianceRepeat.patchValue({
      organizationname: "",
      designation: "",
      joineddate: "",
      reliveddate: ""
    });
    this.rpt_btn_name = this.btn_add;
  }
  clear_fields() {
    this.userprofileForm.patchValue({
      about: "",
      address: "",
      zipcode: "",
      linkedin: "",
      education: "",
      experiance: "",
      resume: ""
    });
    this.rpt_btn_name = this.btn_add;
  }
}
