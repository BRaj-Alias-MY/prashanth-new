import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ApiService} from '../../services/api.service';

@Component({
  selector: 'app-legalagreement',
  templateUrl: './legalagreement.component.html',
  styleUrls: ['./legalagreement.component.css']
})
export class LegalagreementComponent implements OnInit {

  constructor(private api:ApiService,private router: Router) {}
  ngOnInit() {
  }
  agree(){
    this.api.legalagreement().subscribe(res=>{
     if(res.status){
      let usrdata = this.api.getUser();
      usrdata.aggrement = 1;
      localStorage.setItem("user", JSON.stringify(usrdata));
      this.router.navigate(['/login']);
     }else
        this.router.navigate(['/login']);
  });
  }
  reject(){
    this.api.logout();
    this.router.navigate(['/login']);
  }
}
