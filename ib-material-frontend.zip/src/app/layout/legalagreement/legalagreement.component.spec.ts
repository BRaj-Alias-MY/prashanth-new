import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalagreementComponent } from './legalagreement.component';

describe('LegalagreementComponent', () => {
  let component: LegalagreementComponent;
  let fixture: ComponentFixture<LegalagreementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LegalagreementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LegalagreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
