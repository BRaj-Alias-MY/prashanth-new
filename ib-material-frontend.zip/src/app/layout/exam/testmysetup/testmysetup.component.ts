import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-testmysetup',
  templateUrl: './testmysetup.component.html',
  styleUrls: ['./testmysetup.component.css']
})
export class TestmysetupComponent implements OnInit {
  @ViewChild('video') public video: ElementRef;
  title = "Test My Setup";
  button_title = "Ready to Start";

  connectionStatus = 1;

  constructor(private router: Router) { }

  startval: any;
  errormsg: any;
  successflag = 'success';
  mystatus: any;
  startnow: any;

  selectedVideoDevice: string;
  selectedAudioDevice: string;
  selectedBrowser: string;
  isonline: boolean;
  netstats: string;
  browser: string;
  audiostatus: boolean;
  videostatus: boolean;
  networkstatus: boolean;
  browserstatus: boolean;
  streamvideostatus: boolean;
  showText: boolean;
  TextMessage: string;
  showError: boolean;
  canJoinTest: boolean;
  canStopTest: boolean;
  errorMessage: string;

  availableVideoDevices: Array<{ deviceId: string; name: string }>;
  availableAudioDevices: Array<{ deviceId: string; name: string }>;
  availableBrowsers: Array<{ deviceId: string; name: string }>;

  public ngOnInit() {
    $(document).ready(function () {
      var win;
      $('#newbtn').click(function () {
        var strWindowFeatures = "location=yes,height=570,width=100%,scrollbars=yes,status=yes";
        //window.open("http://localhost:4200/examboard/mock", "_blank", strWindowFeatures);

        win = window.open('http://localhost:4200/examboard/mock', 'popup_name', 'height=' + screen.height + ',width=' + screen.width + ',resizable=yes,scrollbars=yes,toolbar=yes,menubar=yes,location=yes')
      });

    });
    this.showText = false;
    this.showError = false;
    this.canJoinTest = true;
    this.canStopTest = false;
    this.availableVideoDevices = [];
    this.availableAudioDevices = [];
    this.availableBrowsers = [];
    this.selectedVideoDevice = undefined;
    this.selectedAudioDevice = undefined;
    this.selectedBrowser = undefined;
    this.isonline = undefined;
    this.netstats = undefined;
    this.audiostatus = undefined;
    this.videostatus = undefined;
    this.networkstatus = undefined;
    this.browser = undefined;
    this.browserstatus = undefined;
    this.streamvideostatus = undefined;
    this.detectDevices();
  }

  private detectDevices() {
    navigator.mediaDevices
      .enumerateDevices()
      .then((devices) => {
        devices.forEach((device) => {
          if (device.kind === 'audioinput') {
            if (!this.selectedAudioDevice) {
              this.selectedAudioDevice = device.deviceId;
            }
            this.availableAudioDevices.push({
              deviceId: device.deviceId,
              name: device.label || `microphone ${this.availableAudioDevices.length + 1}`
            });
          } else if (device.kind === 'videoinput') {
            if (!this.selectedVideoDevice) {
              this.selectedVideoDevice = device.deviceId;
            }
            this.availableVideoDevices.push({
              deviceId: device.deviceId,
              name: device.label || `camera ${this.availableVideoDevices.length + 1}`
            });
          }
        });
        if (this.selectedAudioDevice) {
          this.audiostatus = true;
        } else {
          this.audiostatus = false;
        }
        if (this.selectedVideoDevice) {
          this.videostatus = true;
        } else {
          this.videostatus = false;
        }

        this.selectedBrowser = navigator.userAgent;
        if (navigator.userAgent) {
          this.browser = window.navigator.userAgent;
          this.browserstatus = true;
        }

        this.isonline = navigator.onLine;
        if (navigator.onLine) {
          this.netstats = 'Connected';
          this.networkstatus = true;
        } else {
          this.netstats = 'Not Connected';
          this.networkstatus = false;
        }
      })
      .catch((error) => this.handleError(error));
  }

  onStart() {
    this.startval = 'checking';
    this.startTest();
  }
  onstop() {
    this.startval = '';
    this.stopTest();
  }

  onVideoDeviceChange(videoDevice) {
    this.selectedVideoDevice = videoDevice;
    this.canJoinTest = true;
    this.canStopTest = true;
  }
  onAudioDeviceChange(audioDevice) {
    this.selectedAudioDevice = audioDevice;
    this.canJoinTest = true;
    this.canStopTest = true;
  }
  startTest() {
    this.showError = true;
    const audioSource = this.selectedAudioDevice;
    const videoSource = this.selectedVideoDevice;
    const browserSource = this.selectedBrowser;
    const constraints = {
      audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
      video: { deviceId: videoSource ? { exact: videoSource } : undefined },
      browser: { deviceId: browserSource ? { exact: browserSource } : undefined }
    };
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && navigator.onLine && navigator.userAgent) {
      navigator.mediaDevices
        .getUserMedia(constraints)
        .then((stream) => {
          this.video.nativeElement.srcObject = stream;
          this.video.nativeElement.muted = true;
          this.video.nativeElement.play();
          this.showText = false;
          this.canJoinTest = true;
          this.canStopTest = true;
          this.streamvideostatus = true;
          this.successflag = 'success';
        })
        .catch((error) => this.handleError(error));
    } else {
      this.canStopTest = false;
      this.successflag = 'fail';
      this.errormsg = 'Something went wrong ! Your Equipment is not Working Properly You Cannot Go To Take Interview';
    }
  }
  stopTest() {
    this.showError = false;
    // const stream = this.video.nativeElement.srcObject;
    // const tracks = stream.getTracks();
    // tracks.forEach(function (track) {
    //   track.stop();
    // })
    this.video.nativeElement.srcObject = null;
    this.showText = true;
    this.canJoinTest = false;
    this.canStopTest = false;
    this.mystatus = 'If You Can See Yourself Your Equipment is Working Sucessfully';
    this.startnow = 'ready';
    // this.successflag = 'success';
    // alert('If You Can See Yourself Your Equipment is Working Sucessfully');
  }

  private handleError(error) {
    this.showError = true;
    this.errorMessage = error.toString();
    alert('errorMessage');
  }
  gotoMock() {
    localStorage.setItem('profile', 'yes');
    this.router.navigate(['/examboard/mock']);
  }

}
