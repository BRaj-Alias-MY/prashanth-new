import { Component, OnInit } from "@angular/core";
import { AppService } from "../../../app.service";
import { FormControl, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { Dialog1Component } from "../dialog1/dialog1.component";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ApiService } from "../../../services/api.service";
@Component({
  selector: "app-entrypage",
  templateUrl: "./entrypage2.component.html",
  styleUrls: ["./entrypage2.component.css"]
})
export class Entrypage2Component implements OnInit {
  interviews = [];
  pin: any;
  pinResponse = [];
  myForm: FormGroup;
  Verifypin = "Verify PIN";

  status = localStorage.getItem("status");
  pin2 = localStorage.getItem("pin");
  email = localStorage.getItem("email");
  domain = localStorage.getItem("domain");
  subdomain = localStorage.getItem("subdomain");
  totals: any;
  available: any;
  completed: any;
  payment: any;
  reviewed: any;
  constructor(
    private api: ApiService,
    private router: Router,
    private dialog: MatDialog,
    private service: AppService
  ) {
    this.myForm = this.myFormGroup();
  }

  ngOnInit() {
    localStorage.setItem("profile", "no");
    this.getInterview();
    this.getdashtotals();
  }

  openDialog() {
    /*
    this.dialog.open(Dialog1Component, {
      width: '90%'

    });
    */
  }

  getInterview() {
    const email = localStorage.getItem("email");
    //alert(this.email + this.domain + this.subdomain);
    this.service.getInterviews().subscribe(
      resp => {
        this.interviews = resp;
        console.log(resp);
      },
      err => console.log(err)
    );
  }
  onSubmit(myForm) {
    this.pin = myForm["pin"];
    console.log(this.pin);
    localStorage.setItem("pin", this.pin);
    this.service.getPin(this.pin).subscribe(
      resp => {
        this.pinResponse = resp;
        console.log(this.pinResponse);
        localStorage.setItem("interviewtime", resp["timetaken"]);
        localStorage.setItem("InterviewId", resp["interviewId"]);
        localStorage.setItem("status", resp["status"]);
      },
      err => console.log(err)
    );
  }
  myFormGroup() {
    return new FormGroup({
      pin: new FormControl()
    });
  }

  logout() {
    this.api.logout();
    this.router.navigate(["/login"]);
  }
  getdashtotals() {
    this.service.getDashboardTotals(this.email).subscribe(
      resp => {
        this.totals  = resp;
        console.log(this.totals);
        //console.log(resp[0]["availableInterviews"]);
        this.available = resp[0]["availableInterviews"];
        this.completed = resp[1]["availableInterviews"];
        this.payment = resp[2]["availableInterviews"];
         this.reviewed = resp[3]["availableInterviews"];
      },
      err => console.log(err)
    );
  }
}
